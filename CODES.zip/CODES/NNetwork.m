clc
clear
filename=("ConcreteDataset.csv");
tbl=readtable(filename,'TextType','String');
tbl=splitvars(tbl);
head(tbl);


% Partition training and test partitions
numObservations = size(tbl,1);
numObservationsTrain = floor(0.85*numObservations);
numObservationsTest = numObservations - numObservationsTrain;

idx = randperm(numObservations);
idxTrain = idx(1:numObservationsTrain);
idxTest = idx(numObservationsTrain+1:end);

tblTrain = tbl(idxTrain,:);
tblTest = tbl(idxTest,:);


%Extracting the data

X=tblTrain{:, {'W', 'fck', 'Lx', 'Lratio'}};
Y=tblTrain{:,{'h'}};

data=[X,Y];

basicnet=feedforwardnet([3],'traingd');

% Set up the training parameters
net.trainParam.epochs = 100;  % You can adjust the number of epochs
net.trainParam.lr = 0.01;  % Learning rate


basicnet=train(basicnet,transpose(X),transpose(Y));


