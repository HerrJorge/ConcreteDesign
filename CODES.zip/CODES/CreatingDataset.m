clc
clear


%% INPUTS

% Inputs that do not change %

fyk=500;                    %(N/mm^2) Steel Strength
bar=12;                     %(mm) Bar dia*Assumed*
cover=30;                   %(mm) Cover *Assumed*
dapost=50;                  %(mm) Depth to Compression reinforcement *Assumed*

%Moment coeffcient for slabs. (For the generated Length Ratios/Interior panels)

%bsxn=[0.031 0.044 0.053 0.059 0.063];
%bsyn=0.024;

bsx=[0.024 0.034 0.040 0.044 0.048];
bsy=0.024;

%Carbon Factors(for all fck)
ConcreteCF=[0.093 0.1 0.1 0.12 0.12 0.138 0.138]; %(kgCO2e/kg) *Obtained from IStructe Carbon Tool
SteelCF=0.760;

%Densities
rhoc=2.40*1000;     %(kg/m^3)
rhos=7.85*1000;     %(kg/m*3)

% Variables %

% 1. Load
w=1:1:7;                   %(kN/m^2) Imposed Loading

% 2. Concrete Strength
fck=20:5:50;               %(N/mm^2) Concrete Strength

% 3. Short Span
Lx= 2:1:8;                 %(m) Short Span

% 4. Longer Length
Lratio=[1,1.25,1.5,1.75,2];     %(m) Length Ratios (Ly/Lx)
Ly=transpose(Lratio)*Lx;        %(m) Longer Span (alls spans)

% 5. Slab depth (h)
hslab=150:25:350;           %(mm)slab depth
dslab=hslab-bar/2-cover;    %(mm)slab effective depth(bottom bars)
d2=dslab-bar;              %(mm)slab effective depth(top bars)

%% LOOPS
% Pre-memo %

KEY=combinations(w,fck,Lx,Lratio,hslab);
Combinations=length(w)*length(fck)*length(Lx)*length(Lratio)*length(hslab);
Combi=length(w)*length(fck)*length(Lx)*length(Lratio);
Opti=zeros(Combi,8);

count=0;
countall=0;

Emitottemp=1e89;

Vc=zeros(1,Combinations);
Vs=zeros(1,Combinations);
SRatio=zeros(1,Combinations);
Emis=zeros(1,Combinations);
Emic=zeros(1,Combinations);
Emitot=zeros(1,Combinations);
error=zeros(1,Combinations);
Optitemp=zeros(length(hslab),8);
Optimum=zeros(1,8);


%For all loads
for p=1:length(w)
    %For all concrete
    for i=1:length(fck)
        %For all Lx
        for j=1:length(Lx)
            %for all Lratios
            for y=1:length(Lratio)
                countall=countall+1;
                %for all slab depths
                for o=1:length(hslab)
                    count=count+1;
    
                    % 1. Loads

                    %Self weight of Slab
                    wslab=hslab(1,o)*25*1e-3;       %(KN/m^2);

                    %Ultimate load
                    n=1.35*(wslab)+1.5*(w(1,p));     %(KN/m^2)

                    % 2. Bending-Short (Bottom Bars)
                    Mx=(bsx(1,y)*n*Lx(1,j)^2)*1e6;      %(Nmm) Moment
                    [Asx,Asapostx]=FlexureDesign(Mx,fck(i),fyk,1000,dslab(o),hslab(o),dapost);

                    if isnan(Asx)||isnan(Asapostx)
                        [Vc(count),Vs(count),SRatio(count),Emis(count),Emic(count),Emitot(count)]=change();
                        error(count)=1;
                        continue
                    end

                    % 3. Deflection-Short
                    [Asx,Asapostx]=DeflectionCheck(Asx,Asapostx,1000,dslab(o),fck(i),Lx(1,j));

                    if isnan(Asx)||isnan(Asapostx)
                        [Vc(count),Vs(count),SRatio(count),Emis(count),Emic(count),Emitot(count)]=change();
                        error(count)=2;
                        continue
                    end

                    % 4. Bending-Long (Top Bars)
                    My=(bsy*n*Lx(1,j)^2)*1e6;      %%(Nmm) Moment
                    [Asy,Asaposty]=FlexureDesign(My,fck(i),fyk,1000,d2(1,o),hslab(o),dapost);

                    if isnan(Asy)||isnan(Asaposty)
                        [Vc(count),Vs(count),SRatio(count),Emis(count),Emic(count),Emitot(count)]=change();
                        error(count)=3;
                        continue
                    end
                    % 5. Deflection-Long
                    [Asy,Asaposty]=DeflectionCheck(Asy,Asaposty,1000,d2(1,o),fck(i),Lx(1,j));

                    if isnan(Asy)||isnan(Asaposty)
                        [Vc(count),Vs(count),SRatio(count),Emis(count),Emic(count),Emitot(count)]=change();
                        error(count)=4;
                        continue
                    end
                    % 6. Shear Check
                    Vy=n*Lx(1,j)/4*1e3; %N
                    Vx=n*Ly(y,j)/4*1e3; %N
                    [Asx,Asapostx]= ShearDesignSlab(Vx,dslab(o),1000,Asx,Asaposty,fck(i));
                    [Asy,Asaposty]= ShearDesignSlab(Vy,d2(o),1000,Asy,Asaposty,fck(i));

                    if isnan(Asx)||isnan(Asapostx)
                        [Vc(count),Vs(count),SRatio(count),Emis(count),Emic(count),Emitot(count)]=change();
                        error(count)=5;
                        continue
                    end

                    if isnan(Asy)||isnan(Asaposty)
                        [Vc(count),Vs(count),SRatio(count),Emis(count),Emic(count),Emitot(count)]=change();
                        error(count)=6;
                        continue
                    end

                    % Final Calculations
                    Vc(count)=Lx(1,j)*Ly(y,j)*hslab(1,o)/1000;   %(m^3)
                    Vs(count)=(Asx*Ly(y,j)+Asy*Lx(1,j)+Asapostx*Ly(y,j)+Asaposty*Lx(1,j))/1000;    %(m^3) %%%%CHECHK MIGHT BE WRONG
                    SRatio(count)=Vs(count)/Vc(count);
                    Emic(count)=Vc(count)*rhoc*ConcreteCF(1,i);
                    Emis(count)=Vs(count)*rhos*SteelCF;
                    Emitot(count)=Emic(count)+Emis(count);


                    if Emitot(count)<Emitottemp && Emitot(count)>0

                        Optimum(1,1)=w(1,p);
                        Optimum(1,2)=fck(1,i);
                        Optimum(1,3)=Lx(1,j);
                        Optimum(1,4)=Lratio(1,y);
                        Optimum(1,5)=hslab(1,o);
                        Optimum(1,6)=Asx;
                        Optimum(1,7)=Asy;
                        Optimum(1,8)=Emitot(count);
                        Emitottemp=Emitot(count);
                    end
                end
               Opti(countall,:)=Optimum;
               Emitottemp=1e99;
            end
        end
    end
end

KEY.Concrete_Volume=Vc(:);
KEY.Steel_Volume=Vs(:);
KEY.Ratio=SRatio(:);
KEY.Total_Emissions=Emic(:);

table=sortrows(KEY,"Total_Emissions");


a2t = array2table(Opti,"VariableNames",["w","fck","Lx",'LRatio','hslab','Asx','Asy','Emitot']);



function [A,B,C,D,E,F] = change()

A=0;
B=0;
C=0;
D=0;
E=0;
F=0;
end


















