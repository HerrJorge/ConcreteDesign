function [Emitot]=TwoWaySlabV2(w,fck,L1,L2,n1,n2,min1,min2,hslab,ConcreteCF,SteelCF)

l1=L1/n1;
l2=L2/n2;

if l1<min1
    Emitot=10e90;
    return
end

if l2<min2
    Emitot=10e90;
    return
end


ls=[l1 l2];

Lx=min(ls);
Ly=max(ls);

nobeams=(n1+1)*(n2+1);

Lratio=Ly/Lx;


%If ratio is the 
if Lratio>2
    Emitot=10e90;
    return
end


fyk=500;                    %(N/mm^2) Steel Strength
bar=12;                     %(mm) Bar dia*Assumed*
cover=30;                   %(mm) Cover *Assumed*
dapost=50;                  %(mm) Depth to Compression reinforcement *Assumed*
d1=hslab-bar/2-cover; 
d2=d1-bar;

%interpolation of slab coefficients (So for all types of ratios)
Lratios = [1 1.25 1.5 1.75 2.0];
Mcoeff = [0.024 0.034 0.040 0.044 0.048];
splineInterpolant = spline(Lratios,Mcoeff);

%Moment coefficients
bsx=ppval(splineInterpolant, Lratio);
bsy=0.024;

%Densities
rhoc=2.40*1000;     %(kg/m^3)
rhos=7.85*1000;     %(kg/m*3)

%% Calculations

% 1. Loads

%Self weight of Slab
wslab=hslab*25*1e-3;       %(KN/m^2);

%Ultimate load
n=1.35*(wslab)+1.5*(w);     %(KN/m^2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2. Bending-Short Direction(Bottom Bars)
Mx=(bsx*n*Lx^2)*1e6;      %(Nmm) Moment
b=1000;
%%STEPS
Kbal1=0.167;
zbal1=0.82*d1;
K1=Mx/(b*d1^2 *fck);
if K1<Kbal1 %No compression reinforcement required
    z1=d1*(0.5+sqrt(0.25-K1/1.134));
    As1=Mx/(0.87*fyk*z1);
    Asapost1=0;
else %Compression reinforcement required
    Asapost1=(K1-Kbal1)*fck*b*d1^2 /(0.87*fyk*(d1-dapost));
    As1=Kbal1*fck*b*d1^2/(0.87*fyk*zbal1)+Asapost1;   %Assume this is Asprov; CANNOT ENSURE DUCTILITY IN THE SECTION
end

%%%
if 100*As1/(b*d1)<(0.26*(0.3*fck^(2/3)/fyk))|| 100*As1/(b*hslab)>4 || 100*As1/b/d1<0.15 %If outside threshold... Slab does not work
    clear As1 Asapost1
    Emitot=10e90;
    return

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2. Bending-Long Direction(Bottom Bars)
My=(bsy*n*Lx^2)*1e6;
Kbal2=0.167;
zbal2=0.82*d2;
K2=My/(b*d2^2 *fck);
if K2<Kbal2 %No compression reinforcement required
    z2=d2*(0.5+sqrt(0.25-K2/1.134));
    As2=My/(0.87*fyk*z2);
    Asapost2=0;
else %Compression reinforcement required
    Asapost2=(K2-Kbal2)*fck*b*d2^2 /(0.87*fyk*(d2-dapost));
    As2=Kbal2*fck*b*d2^2/(0.87*fyk*zbal2)+Asapost2;   %Assume this is Asprov; CANNOT ENSURE DUCTILITY IN THE SECTION
end

if 100*As2/(b*d2)<(0.26*(0.3*fck^(2/3)/fyk))|| 100*As2/(b*hslab)>4  || 100*As2/b/d2<0.15 %If outside threshold... Slab does not work
    clear As2 Asapost2
    Emitot=10e90;
    return
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3. Deflection Check

aratio=Ly*1000/d1;                  %Actual Ratio
dratiomax=30;                       % Limit span/depth ratio(Same for slab and beam)
rratio=100*As1/(b*d1);                     % Tension Reinforcement ratio
rrratio=10^(-3)*sqrt(fck);            % Reference Reinforcement ratios

if rratio<= rrratio   %Scenario one
    dratio=1.5*(11+1.5*sqrt(fck)*rrratio/rratio+3.2*sqrt(fck)*(rrratio/rratio-1)^(3/2));
else                    %Scenario two:
    rratioapost=100*Asapost1/(b*d1);            % Compression Renforcement ratio
    dratio=1.5*(11+1.5*sqrt(fck)*rrratio/(rratio-rratioapost)+1/12*sqrt(fck)*sqrt(rratioapost/rrratio));
end

% Checking
if dratio>dratiomax || dratio>aratio

Emitot=10e90;
return
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 4. Cal Emisssions

%calculating Volume per bay  
Vc=Lx*Ly*hslab/1000;
Vs=(As1*Ly+As2*Lx+Asapost1*Ly+Asapost2*Ly);

%Calculating the emissions per bay 
Emic=Vc*rhoc*ConcreteCF;
Emis=Vs*rhos*SteelCF;
Emibay=Emic+Emis; %per bay

Emibays=Emibay*n1*n2; %total emissions from slab

%Calculating additional emissions from beams

%Calculating all beams required for n1xn2 bays 
Beamlengthtot=L2*(n1+1)+L1*(n2+1);

%Using a sample beam of 250x400 
AreaBeamC=250*400/10^6;%0.12;      %(m^2 per meter)
AreaBeamS=AreaBeamC*0.04;%;0.04;    %(m^2 per meter)

%Volume
VbeamC=AreaBeamC*Beamlengthtot; 
VbeamS=AreaBeamS*Beamlengthtot;

EmiBeamC=VbeamC*rhoc*ConcreteCF;
EmiBeamS=VbeamS*rhos*SteelCF;

EmiBeam=EmiBeamS+EmiBeamC;

%Total Emissions
Emitot=Emibays+EmiBeam;




end







