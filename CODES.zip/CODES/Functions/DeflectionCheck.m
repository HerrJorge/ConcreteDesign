function [As,Asapost]=DeflectionCheck(As,Asapost,b,d,fck,L)
aratio=L*1000/d;
dratiomax=30;                       % Limit span/depth ratio(Same for slab and beam)
rratio=100*As/(b*d);                     % Tension Reinforcement ratio
rrratio=10^(-3)*sqrt(fck);            % Reference Reinforcement ratios

if rratio<= rrratio   %Scenario one
    dratio=1.5*(11+1.5*sqrt(fck)*rrratio/rratio+3.2*sqrt(fck)*(rrratio/rratio-1)^(3/2));
else                    %Scenario two:
    rratioapost=100*Asapost/(b*d);            % Compression Renforcement ratio
    dratio=1.5*(11+1.5*sqrt(fck)*rrratio/(rratio-rratioapost)+1/12*sqrt(fck)*sqrt(rratioapost/rrratio));
end




%% Checking
if dratio>dratiomax || dratio>aratio
    As=NaN;
    Asapost=NaN;
end