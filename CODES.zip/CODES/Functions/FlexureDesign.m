function [As,Asapost]= FlexureDesign(Med,fck,fyk,b,d,h,dapost)

Kbal=0.167;
zbal=0.82*d;
% 
K=Med/(b*d^2 *fck);

if K<Kbal %No compression reinforcement required
    z=d*(0.5+sqrt(0.25-K/1.134));
    As=Med/(0.87*fyk*z);
    Asapost=0;

else %Compression reinforcement required
    
    dratio=dapost/d;
    Asapost=(K-Kbal)*fck*b*d^2 /(0.87*fyk*(d-dapost));
    As=Kbal*fck*b*d^2/(0.87*fyk*zbal)+Asapost;   %Assume this is Asprov; CANNOT ENSURE DUCTILITY IN THE SECTION
end
%Check for min and max steel reinforcement

if 100*As/(b*d)<(0.26*(0.3*fck^(2/3)/fyk))|| 100*As/(b*h)>4  %If outside threshold... Slab does not work
    clear As Asapost
    As=0;
    Asapost=0;
end

end
